import pandas as pd
import cv2
import urllib.request
import numpy as np
import os
from datetime import datetime
import face_recognition

# ------------------ SETTINGS ------------------
# Use the script's directory as base (works anywhere)
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
IMAGE_PATH = os.path.join(BASE_DIR, 'image_folder')
ATTENDANCE_FOLDER = os.path.join(BASE_DIR, 'attendance')
ATTENDANCE_FILE = os.path.join(ATTENDANCE_FOLDER, 'Attendance.csv')
CAMERA_URL = 'http://10.125.210.228/cam-hi.jpg'
FRAME_SCALE = 0.25  # scale down frame for faster face recognition
FRAME_SKIP = 2      # process every 2nd frame
# ----------------------------------------------

# Ensure attendance folder exists
os.makedirs(ATTENDANCE_FOLDER, exist_ok=True)

# Initialize Attendance.csv with headers
if not os.path.exists(ATTENDANCE_FILE):
    pd.DataFrame(columns=['Name', 'Time']).to_csv(ATTENDANCE_FILE, index=False)
else:
    print("Found existing Attendance.csv, removing old one...")
    os.remove(ATTENDANCE_FILE)
    pd.DataFrame(columns=['Name', 'Time']).to_csv(ATTENDANCE_FILE, index=False)

# ------------------ LOAD KNOWN FACES ------------------
images = []
classNames = []

if not os.path.exists(IMAGE_PATH):
    print(f"Image folder not found at: {IMAGE_PATH}")
    print(f"Please create the folder and add face images.")
    exit()

myList = os.listdir(IMAGE_PATH)
if not myList:
    print(f"No images found in {IMAGE_PATH}")
    print("Please add face images (jpg, png) to the image_folder directory.")
    exit()

print("Images found:", myList)

for cl in myList:
    curImg = cv2.imread(os.path.join(IMAGE_PATH, cl))
    if curImg is None:
        print(f"Warning: Could not read image {cl}")
        continue
    images.append(curImg)
    classNames.append(os.path.splitext(cl)[0])

print("Classes loaded:", classNames)


def findEncodings(images):
    encodeList = []
    for img in images:
        try:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            encodes = face_recognition.face_encodings(img)
            if encodes:
                encodeList.append(encodes[0])
            else:
                print("No face found in one of the images, skipping.")
        except Exception as e:
            print(f"Encoding error: {e}")
    return encodeList


def markAttendance(name):
    df = pd.read_csv(ATTENDANCE_FILE)
    if name not in df['Name'].values:
        now = datetime.now()
        dtString = now.strftime('%H:%M:%S')
        df = pd.concat([df, pd.DataFrame({'Name':[name], 'Time':[dtString]})], ignore_index=True)
        df.to_csv(ATTENDANCE_FILE, index=False)


print("Encoding faces, please wait...")
encodeListKnown = findEncodings(images)
print(f'Face Encodings Complete - {len(encodeListKnown)} faces encoded')

if not encodeListKnown:
    print("No valid face encodings found. Please check your images.")
    exit()

# ------------------ MAIN LOOP ------------------
print("Starting camera stream...")
print("Press 'q' to quit")
frameCounter = 0

while True:
    try:
        # Fetch frame from IP camera
        img_resp = urllib.request.urlopen(CAMERA_URL, timeout=5)
        imgnp = np.array(bytearray(img_resp.read()), dtype=np.uint8)
        frame = cv2.imdecode(imgnp, -1)

        frameCounter += 1
        process_frame = frame.copy()

        # ---- FACE RECOGNITION ----
        if frameCounter % FRAME_SKIP == 0:
            small_frame = cv2.resize(process_frame, (0, 0), fx=FRAME_SCALE, fy=FRAME_SCALE)
            small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

            facesCurFrame = face_recognition.face_locations(small_frame)
            encodesCurFrame = face_recognition.face_encodings(small_frame, facesCurFrame)

            for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
                matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
                faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
                matchIndex = np.argmin(faceDis)

                if matches[matchIndex]:
                    name = classNames[matchIndex].upper()
                    y1, x2, y2, x1 = [v * int(1/FRAME_SCALE) for v in faceLoc]
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    cv2.rectangle(frame, (x1, y2-35), (x2, y2), (0, 255, 0), cv2.FILLED)
                    cv2.putText(frame, name, (x1+6, y2-6), cv2.FONT_HERSHEY_COMPLEX, 1, (255,255,255), 2)
                    markAttendance(name)

        cv2.imshow('Camera', frame)
        if cv2.waitKey(5) & 0xFF == ord('q'):
            break

    except Exception as e:
        print(f"Stream Error: {e}")
        continue  # try next frame instead of breaking

cv2.destroyAllWindows()
print("Program terminated.")