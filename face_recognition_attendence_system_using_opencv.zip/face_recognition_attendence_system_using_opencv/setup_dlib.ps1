Write-Host "🌸 Checking for C++ compiler..." -ForegroundColor Cyan
$compiler = Get-Command cl -ErrorAction SilentlyContinue

if (-not $compiler) {
    Write-Host "⚙️  Visual Studio Build Tools not found. Installing..." -ForegroundColor Yellow
    Write-Host "This may take 10–20 minutes depending on your internet speed." -ForegroundColor DarkYellow
    
    # Download and install Visual Studio Build Tools (C++ workload)
    $url = "https://aka.ms/vs/17/release/vs_BuildTools.exe"
    $installer = "$env:TEMP\vs_BuildTools.exe"
    Invoke-WebRequest $url -OutFile $installer
    Start-Process -FilePath $installer -ArgumentList "--add Microsoft.VisualStudio.Workload.VCTools --includeRecommended --quiet --wait" -Wait

    Write-Host "✅ Visual Studio Build Tools installed successfully!" -ForegroundColor Green
} else {
    Write-Host "✅ C++ compiler already installed!" -ForegroundColor Green
}

Write-Host "🚀 Setting up Python environment..." -ForegroundColor Cyan

# Create virtual environment if not exists
if (-not (Test-Path "venv")) {
    python -m venv venv
    Write-Host "🌱 Virtual environment created." -ForegroundColor Green
}

# Activate environment
& ".\venv\Scripts\activate"

# Upgrade pip and core build tools
pip install --upgrade pip setuptools wheel

# Install cmake and dlib first
pip install cmake dlib --no-cache-dir

# Install remaining libraries
pip install chardet click decorator face-recognition face-recognition-models idna imageio imageio-ffmpeg moviepy numpy pandas opencv-python Pillow proglog requests tqdm urllib3 wincertstore --ignore-installed

Write-Host "🎉 Setup complete! Your environment is ready to use." -ForegroundColor Green
